using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace project_log_web.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile logFile)
        {
            if (logFile == null || logFile.Length == 0)
            {
                ViewBag.Result = "ERROR: No file uploaded";
                return View("Index");
            }

            // Create uploads directory
            var uploadsDir = Path.Combine(
                Directory.GetCurrentDirectory(),
                "uploads"
            );

            Directory.CreateDirectory(uploadsDir);

            // Save uploaded file
            var logPath = Path.Combine(uploadsDir, logFile.FileName);

            using (var stream = new FileStream(logPath, FileMode.Create))
            {
                await logFile.CopyToAsync(stream);
            }

            // Path to C++ executable
            var exePath = Path.Combine(
                Directory.GetCurrentDirectory(),
                "Tools",
                "project log.exe"
            );

            if (!System.IO.File.Exists(exePath))
            {
                ViewBag.Result = "ERROR: C++ executable not found in Tools folder";
                return View("Index");
            }

            // Run C++ executable
            var process = new Process();
            process.StartInfo.FileName = exePath;
            process.StartInfo.Arguments = $"\"{logPath}\"";
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.CreateNoWindow = true;

            process.Start();
            string output = await process.StandardOutput.ReadToEndAsync();
            process.WaitForExit();

            ViewBag.Result = output;
            System.IO.File.Delete(logPath);

            return View("Index");
        }
    }
}

