#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

using namespace std;

/*
    Stores the time (in seconds since midnight)
    of an ERROR event.
*/
struct ErrorEvent {
    int timeInSeconds;
};

/*
    Converts a time string (HH:MM:SS)
    into total seconds since midnight.
*/
int convertTimeToSeconds(const string& timeText) {
    int hours, minutes, seconds;
    char separator;

    stringstream ss(timeText);
    ss >> hours >> separator >> minutes >> separator >> seconds;

    return (hours * 3600) + (minutes * 60) + seconds;
}

int main(int argc, char* argv[]) {

    // 1. Validate input
    if (argc < 2) {
        cout << "ERROR: Log file path not provided\n";
        return 1;
    }

    // 2. Open log file
    ifstream logFile(argv[1]);
    if (!logFile.is_open()) {
        cout << "ERROR: Unable to open log file\n";
        return 1;
    }

    // 3. Counters
    int totalLineCount = 0;
    int infoCount = 0;
    int warningCount = 0;
    int errorCount = 0;

    // Store timestamps of ERROR events
    vector<ErrorEvent> errorEvents;

    // 4. Read log file line by line
    string logLine;
    while (getline(logFile, logLine)) {

        totalLineCount++;

        if (logLine.find("INFO") != string::npos) {
            infoCount++;
        }
        else if (logLine.find("WARNING") != string::npos) {
            warningCount++;
        }
        else if (logLine.find("ERROR") != string::npos) {
            errorCount++;

            // Extract time from format: YYYY-MM-DD HH:MM:SS
            if (logLine.length() >= 19) {
                string timeText = logLine.substr(11, 8);
                int seconds = convertTimeToSeconds(timeText);
                errorEvents.push_back({ seconds });
            }
        }
    }

    logFile.close();

    // 5. Detect burst of ERROR events
    bool burstFound = false;
    int burstStartTime = 0;
    int burstEndTime = 0;

    for (size_t i = 0; i < errorEvents.size(); i++) {

        int eventsInWindow = 1;

        for (size_t j = i + 1; j < errorEvents.size(); j++) {

            int timeDifference =
                errorEvents[j].timeInSeconds -
                errorEvents[i].timeInSeconds;

            if (timeDifference <= 10) {
                eventsInWindow++;

                if (eventsInWindow >= 5) {
                    burstFound = true;
                    burstStartTime = errorEvents[i].timeInSeconds;
                    burstEndTime = errorEvents[j].timeInSeconds;
                    break;
                }
            }
            else {
                break;
            }
        }

        if (burstFound) {
            break;
        }
    }

    // 6. Print analysis report
    cout << "LOG ANALYSIS REPORT\n";
    cout << "===================\n";
    cout << "Total lines: " << totalLineCount << "\n";
    cout << "INFO: " << infoCount << "\n";
    cout << "WARNING: " << warningCount << "\n";
    cout << "ERROR: " << errorCount << "\n\n";

    if (burstFound) {
        cout << "⚠ ERROR BURST DETECTED\n";
        cout << "Time window (seconds): "
            << burstStartTime << " - "
            << burstEndTime << "\n";
    }
    else {
        cout << "No error bursts detected\n";
    }

    return 0;
}
